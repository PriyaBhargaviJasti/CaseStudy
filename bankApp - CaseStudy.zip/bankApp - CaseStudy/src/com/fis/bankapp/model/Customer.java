package com.fis.bankapp.model;

//import java.util.Date;

public class Customer {
	private int custId;
	private String custName;
	private String custDob;
	private long mobile;
	private String custMail;  
	private long accNo;
	private String custAddress;

	public int getcustId() {
		return custId;
	}

	public void setcustId(int custId) {
		this.custId = custId;
	}

	public String getcustName() {
		return custName;
	}

	public void setcustName(String custName) {
		this.custName = custName;
	}
	
	public String getcustDob() {
		return custDob;
	}

	public void setcustDob(String custDob) {
		this.custDob = custDob;
	}

	public long getmobile() {
		return mobile;
	}

	public void setmobile(long mobile) {
		this.mobile = mobile;
	}

	public String getcustMail() {
		return custMail;
	}

	public void setcustMail(String custMail) {
		this.custMail = custMail;
	}
	
	public long accNo() {
		return accNo;
	}

	public void setaccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getcustAddress() {
		return custAddress;
	}

	public void setcustAddress(String custAddress) {
		this.custAddress = custAddress;
	}


	public Customer(int custId, String custName, String custDob, long mobile, String custMail, long accNo, String custAddress) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custDob = custDob;
		this.mobile = mobile;
		this.custMail = custMail;
		this.accNo = accNo;
		this.custAddress = custAddress;
	}
/*
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(int custId, String custName, String custDob, long mobile, String custMail, String custAddress) {
		// TODO Auto-generated constructor stub
	}
*/
	@Override
	public String toString() {
		return "[custId=" + custId + ", custName=" + custName + ", custDob=" + custDob + ", mobile=" + mobile
				+ ", custMail=" + custMail + ", accNo=" + accNo + ", custAddress=" + custAddress + "]";
	}

}
