package com.fis.bankapp.dao;

import java.util.HashMap;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.exceptions.AccountNotFound;
import com.fis.bankapp.exceptions.NotEnoughBalance;

public class AccountDaoImpl implements AccountDao {

	HashMap<Long, Account> Accounts = new HashMap<Long, Account>();

	@Override
	public String addAccount(Account account) {

		Accounts.put(account.getaccNo(), account);

		return "Account Added Successfully!";
	}
	
	@Override
	public String deleteAccount(long accNo) throws AccountNotFound {
		if (Accounts.containsKey(accNo)) {
			Accounts.remove(accNo);
			return "Account Deleted Successfully";
		} else {
			throw new AccountNotFound("Invalid Account Number");
		}
	}

	@Override
	public Account getAccount(long getAcc) throws AccountNotFound {
		if (Accounts.containsKey(getAcc)) {
			return Accounts.get(getAcc);
		} else {
			throw new AccountNotFound("Invalid Account Number");
		}
	}

	@Override
	public void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance{

		if (Accounts.containsKey(getAcc) && (Accounts.get(getAcc).getbalance() - withdrawAmount) > -1) {
			Accounts.get(getAcc).setbalance(Accounts.get(getAcc).getbalance() - withdrawAmount);
		}
		else {
			throw new NotEnoughBalance("Not enough Balance");
		}
	}
	
	@Override
	public void depositIntoBalance(long getAcc, double depositAmount) {

		if (Accounts.containsKey(getAcc)) {
			Accounts.get(getAcc).setbalance(Accounts.get(getAcc).getbalance() + depositAmount);
		}
	}

}
