package com.fis.bankapp.exceptions;

public class AccountNotFound extends Exception {// this exception class is to throw user friendly message

	public AccountNotFound(String message) {
		super(message);
	}

}
