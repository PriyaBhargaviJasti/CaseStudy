package com.fis.bankapp.main;
import java.util.Date;
import java.util.Scanner;
//import java.util.Set;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.model.Account;
import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.exceptions.CustomerNotFound;
import com.fis.bankapp.service.CustomerService;
import com.fis.bankapp.service.CustomerServiceImpl;
import com.fis.bankapp.exceptions.AccountNotFound;
import com.fis.bankapp.service.AccountService;
import com.fis.bankapp.service.AccountServiceImpl;
import com.fis.bankapp.service.TransactionService;
import com.fis.bankapp.service.TransactionServiceImpl;
import com.fis.bankapp.exceptions.NotEnoughBalance;

public class BankApp {

	public static void main(String[] args) throws AccountNotFound {
		int custId = 100;
		String custName;
		String custDob;
		long mobile;
		String custMail;
		String custAddress; 
		long accNo = 1000;
		String accType;
		String branch;
		String ifsc;
		double balance = 0;
		int transId = 10000;
		long accNoFrom; 
		long accNoTo;
		double amount;
		Date dateOfTrans;
		String transType;
		String username;
		String password;

		//Set<Customer> cust = null;
		Customer customer = null;
		CustomerService service = new CustomerServiceImpl();

		//Set<Account> acc = null;
		Account account = null;
		AccountService service2 = new AccountServiceImpl();

		//Set<Transaction> trans = null;
		Transaction transaction = null;
		TransactionService service3 = new TransactionServiceImpl();

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Username : ");
		username = scanner.next();
		System.out.println("Enter Password : ");
		password = scanner.next();
		if(username.equals("fis") && password.equals("fis@123")) {
			while (true) {
				System.out.println("********Bank Services********");
				System.out.println("1.Customer Registration");
				System.out.println("2.Create Account");
				System.out.println("3.Deposit");
				System.out.println("4.Withdraw");
				System.out.println("5.Delete Account");
				System.out.println("6.Show Customer Details");
				System.out.println("7.Show Account Details");
				System.out.println("8.Fund Transfer");
				System.out.println("9.Show Transaction Details");
				System.out.println("10.Exit Application");
				int option = scanner.nextInt();

				switch (option) {
				case 1:
					System.out.println("ENTER DETAILS TO REGISTER");
					System.out.println("Enter Your Name");
					custName = scanner.next();
					System.out.println("Enter Your Date of Birth");
					custDob = scanner.next();
					System.out.println("Enter Your Mobile Number");
					mobile = scanner.nextLong();
					System.out.println("Enter Your Mail ID");
					custMail = scanner.next();
					System.out.println("Enter Your Address");
					custAddress = scanner.next();
					++custId;
					customer = new Customer(custId, custName, custDob, mobile, custMail, accNo, custAddress);
					System.out.println(service.addCustomer(customer) + " with custId: " + custId);

					break;
				case 2:
					System.out.println("ENTER DETAILS TO CREATE ACCOUNT");
					System.out.println("Enter Your Account Type");
					accType = scanner.next();
					System.out.println("Enter Your Branch");
					branch = scanner.next();
					System.out.println("Enter Your Branch IFSC Code");
					ifsc = scanner.next();				
					++accNo;
					account = new Account(custId, accNo, accType, branch, ifsc, balance);
					System.out.println(service2.addAccount(account) + " with accNo: " + accNo);
					break;
				case 3:
					System.out.println("DEPOSIT");
					System.out.println("Enter account number to deposit: ");
					long dpAccNo = scanner.nextLong();
					try {
						System.out.println(service2.getAccount(dpAccNo));
						System.out.println("Enter amount to deposit: ");
						double dpAmount = scanner.nextDouble();
						System.out.println("Old Balance : " + service2.getAccount(dpAccNo).getbalance());
						service2.depositIntoBalance(dpAccNo, dpAmount);
						System.out.println("New Balance : " + service2.getAccount(dpAccNo).getbalance());
					} catch (AccountNotFound anf) {
						System.out.println("Invalid Account Number...");
					}
					finally {
						System.out.println("Deposit Successful.");
						accNoFrom = 0;
						accNoTo = dpAccNo;
						double dpAmount = 0;
						amount = dpAmount;
						dateOfTrans = new Date();
						transType = "Deposit";
						balance = service2.getAccount(dpAccNo).getbalance();
						transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType, balance);
						transId++;
						service3.addDeposit(dpAccNo, transaction);
						System.out.println(service2.getAccount(dpAccNo));
					}
					break;

				case 4:
					System.out.println("WITHDRAW");
					System.out.println("Enter account number to withdraw: ");
					long wdAccNo = scanner.nextLong();
					try {
						System.out.println(service2.getAccount(wdAccNo));
						System.out.println("Enter amount to withdraw: ");
						double wdAmount = scanner.nextDouble();
						if (wdAmount <= (service2.getAccount(wdAccNo).getbalance())) {
							System.out.println("Old Balance : " + service2.getAccount(wdAccNo).getbalance());
							service2.withdrawFromBalance(wdAccNo, wdAmount);
							System.out.println("New Balance : " + service2.getAccount(wdAccNo).getbalance());
						} else {
							throw new NotEnoughBalance("Not enough Balance");
						}
					} catch (AccountNotFound anf) {
						System.out.println("Invalid Account Number...");
					} catch (NotEnoughBalance neb) {
						System.out.println("Not enough Balance");
					}
					finally {
						System.out.println("Deposit Successful.");
						accNoFrom = wdAccNo;
						accNoTo = 0;
						double wdAmount = 0;
						amount = wdAmount;
						dateOfTrans = new Date();
						transType = "Withdraw";
						balance = service2.getAccount(wdAccNo).getbalance();
						transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType, balance);
						transId++;
						service3.addWithdraw(wdAccNo, transaction);
						System.out.println(service2.getAccount(wdAccNo));
					}
					break;

				case 5:
					System.out.println("Delete Account");
					System.out.println("Enter Your Account Number");
					accNo = scanner.nextLong();
					try {
						System.out.println(service2.deleteAccount(accNo));
					} catch (AccountNotFound e) {
						System.out.println("Enter valid Account Number....");
					}
					break; 
				case 6:
					System.out.println("Enter Customer Details To Get");
					System.out.println("Enter Your Customer ID");
					custId = scanner.nextInt();
					try {
						System.out.println(service.getCustomer(custId));
					} catch (CustomerNotFound e) {
						System.out.println("Enter valid Customer Id....");
					}
					break;
					/*	case 6:
				System.out.println("Customers Info:");
				cust = service.getAllCustomers();
				for (Customer cus : cust) {
					System.out.println(cus);
				}
				break; */
				case 7:
					System.out.println("Enter Account Details To Get");
					System.out.println("Enter Your Account Number");
					accNo = scanner.nextInt();
					try {
						System.out.println(service2.getAccount(accNo));
					} catch (AccountNotFound e) {
						System.out.println("Enter valid Account Number....");
					}
					break;

				case 8:
					System.out.println("FUND TRANSFER");
					System.out.println("Enter your account number to start transaction: ");
					long transFromAcc = scanner.nextLong();
					try {
						System.out.println(service2.getAccount(transFromAcc));
						System.out.println("Enter which service you wish to use:\n1. NEFT\n2. RTGS\n3. IMPS");
						int transServiceRequested = scanner.nextInt();
						switch (transServiceRequested) {
						case 1:
							System.out.println("NEFT selected...");
							System.out.println("Enter beneficiary account number: ");
							long neftAccNo = scanner.nextLong();
							try {
								service2.getAccount(neftAccNo);
							} catch (AccountNotFound anf) {
								System.out.println("Wrong Account Number of beneficiary... Transaction Cancelled...");
							}
							System.out.println("Enter Amount to transfer: ");
							double neftAmount = scanner.nextDouble();


							try {
								double transWithdrawAmount = neftAmount;
								if (transWithdrawAmount <= (service2.getAccount(transFromAcc).getbalance())) {
									System.out.println("Old Balance of " + transFromAcc + " is " + service2.getAccount(transFromAcc).getbalance());
									service2.withdrawFromBalance(transFromAcc, transWithdrawAmount);
									System.out.println("New Balance of " + transFromAcc + " is " + service2.getAccount(transFromAcc).getbalance());
								} else {
									throw new NotEnoughBalance("Not enough Balance");
								}
							} catch (NotEnoughBalance neb) {
								System.out.println("Not enough Balance");
								break;
							}

							try {
								double transDepositAmount = neftAmount;
								System.out.println("Old Balance of " + neftAccNo + " is " + service2.getAccount(neftAccNo).getbalance());
								service2.depositIntoBalance(neftAccNo, transDepositAmount);
								System.out.println("New Balance of " + neftAccNo + " is " + service2.getAccount(neftAccNo).getbalance());
							} finally {
								System.out.println("Transaction Successful via NEFT.");
								accNoFrom = transFromAcc;
								accNoTo = neftAccNo;
								amount = neftAmount;
								dateOfTrans = new Date();
								transType = "NEFT";
								balance = service2.getAccount(transFromAcc).getbalance();
								transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType, balance);
								transId++;
								service3.addTransactionNEFT(transFromAcc, neftAccNo, transaction);
								System.out.println(service2.getAccount(transFromAcc));
							}

							break;

						case 2:
							System.out.println("RTGS selected...");
							System.out.println("Enter beneficiary account number: ");
							long rtgsAccNo = scanner.nextLong();
							try {
								service2.getAccount(rtgsAccNo);
							} catch (AccountNotFound anf) {
								System.out.println("Wrong Account Number of beneficiary... Transaction Cancelled...");
							}
							System.out.println("Enter Amount to transfer: ");
							double rtgsAmount = scanner.nextDouble();


							try {
								double transWithdrawAmount = rtgsAmount;
								if (transWithdrawAmount <= (service2.getAccount(transFromAcc).getbalance())) {
									System.out.println("Old Balance of " + transFromAcc + " is " + service2.getAccount(transFromAcc).getbalance());
									service2.withdrawFromBalance(transFromAcc, transWithdrawAmount);
									System.out.println("New Balance of " + transFromAcc + " is " + service2.getAccount(transFromAcc).getbalance());
								} else {
									throw new NotEnoughBalance("Not enough Balance");
								}
							} catch (NotEnoughBalance neb) {
								System.out.println("Not enough Balance");
								break;
							}

							try {
								double transDepositAmount = rtgsAmount;
								System.out.println("Old Balance of " + rtgsAccNo + " is " + service2.getAccount(rtgsAccNo).getbalance());
								service2.depositIntoBalance(rtgsAccNo, transDepositAmount);
								System.out.println("New Balance of " + rtgsAccNo + " is " + service2.getAccount(rtgsAccNo).getbalance());
							} finally {
								System.out.println("Transaction Successful via RTGS.");
								accNoFrom = transFromAcc;
								accNoTo = rtgsAccNo;
								amount = rtgsAmount;
								dateOfTrans = new Date();
								transType = "RTGS";
								balance = service2.getAccount(transFromAcc).getbalance();
								transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType, balance);
								transId++;
								service3.addTransactionNEFT(transFromAcc, rtgsAccNo, transaction);
								System.out.println(service2.getAccount(transFromAcc));
							}
							break;
						case 3:
							System.out.println("IMPS selected...");
							System.out.println("Enter beneficiary account number: ");
							long impsAccNo = scanner.nextLong();
							try {
								service2.getAccount(impsAccNo);
							} catch (AccountNotFound anf) {
								System.out.println("Wrong Account Number of beneficiary... Transaction Cancelled...");
							}
							System.out.println("Enter Amount to transfer: ");
							double impsAmount = scanner.nextDouble();


							try {
								double transWithdrawAmount = impsAmount;
								if (transWithdrawAmount <= (service2.getAccount(transFromAcc).getbalance())) {
									System.out.println("Old Balance of " + transFromAcc + " is " + service2.getAccount(transFromAcc).getbalance());
									service2.withdrawFromBalance(transFromAcc, transWithdrawAmount);
									System.out.println("New Balance of " + transFromAcc + " is " + service2.getAccount(transFromAcc).getbalance());
								} else {
									throw new NotEnoughBalance("Not enough Balance");
								}
							} catch (NotEnoughBalance neb) {
								System.out.println("Not enough Balance");
								break;
							}

							try {
								double transDepositAmount = impsAmount;
								System.out.println("Old Balance of " + impsAccNo + " is " + service2.getAccount(impsAccNo).getbalance());
								service2.depositIntoBalance(impsAccNo, transDepositAmount);
								System.out.println("New Balance of " + impsAccNo + " is " + service2.getAccount(impsAccNo).getbalance());
							} finally {
								System.out.println("Transaction Successful via RTGS.");
								accNoFrom = transFromAcc;
								accNoTo = impsAccNo;
								amount = impsAmount;
								dateOfTrans = new Date();
								transType = "IMPS";
								balance = service2.getAccount(transFromAcc).getbalance();
								transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType, balance);
								transId++;
								service3.addTransactionNEFT(transFromAcc, impsAccNo, transaction);
								System.out.println(service2.getAccount(transFromAcc));
							}
							break;
						default:
							System.out.println("Wrong Input... Transaction Cancelled...");
							break;
						}
					} catch (AccountNotFound anf) {
						System.out.println("Enter valid account number...");
					}
					break;
				case 9:
					System.out.println("SHOW ACCOUNT TRANSACTIONS");
					System.out.println("Enter account number to show transactions: ");
					long showTransAccNo = scanner.nextLong();
					try {
						service2.getAccount(showTransAccNo);
						System.out.println(service3.getTransForAccNo(transaction, showTransAccNo)); 
					} catch (AccountNotFound anf) {
						System.out.println("Enter valid account number....");
					}
					break;
					

				case 10:
					System.out.println("Thank You !!!!");
					scanner.close();
					System.exit(0);
					break;
				default:
					System.out.println("Wrong Input. Please Try Again!!!");
				}
			}
			
		}
		else {

			System.out.println("Invalid Credentials");
		}
		scanner.close();

	}

}



