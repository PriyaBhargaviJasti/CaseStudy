package com.fis.bankapp.model;


public class Account {
	private int custId;   
    private long accNo;
    private String accType;
    private String branch;
    private String ifsc;
    private double balance;

	public int getcustId() {
		return custId;
	}

	public void setcustId(int custId) {
		this.custId = custId;
	}

	public long getaccNo() {
		return accNo;
	}

	public void setaccNo(long accNo) {
		this.accNo = accNo;
	}
	
	public String getaccType() {
		return accType;
	}

	public void setaccType(String accType) {
		this.accType = accType;
	}

	public String getbranch() {
		return branch;
	}

	public void setbranch(String branch) {
		this.branch = branch;
	}

	public String getifsc() {
		return ifsc;
	}

	public void setifsc(String ifsc) {
		this.ifsc = ifsc;
	}
	
	public double getbalance() {
		return balance;
	}

	public void setbalance(double balance) {
		this.balance = balance;
	}


	public Account(int custId, long accNo, String accType, String branch, String ifsc, double balance) {
		super();
		this.custId = custId;
		this.accNo = accNo;
		this.accType = accType;
		this.branch = branch;
		this.ifsc = ifsc;
		this.balance = balance;
	}/*
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(int custId, long accNo, String accType, String branch, String ifsc, double balance) {
		// TODO Auto-generated constructor stub
	}
	*/

	@Override
	public String toString() {
		return "[custId=" + custId + ", accNo=" + accNo + ", accType=" + accType + ", branch=" + branch
				+ ", ifsc=" + ifsc + ", balance=" + balance + "]";
	}

}
