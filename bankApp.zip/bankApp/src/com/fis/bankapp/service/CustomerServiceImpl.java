package com.fis.bankapp.service;

import java.util.Set;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.exceptions.CustomerNotFound;
import com.fis.bankapp.dao.CustomerDao;
import com.fis.bankapp.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {

	CustomerDao dao = new CustomerDaoImpl();

	@Override
	public String addCustomer(Customer customer) {
		return dao.addCustomer(customer);
	}

	@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {

		return dao.updateCustomer(customer);
	}

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {

		return dao.deleteCustomer(custId);
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound {

		return dao.getCustomer(custId);
	}

	@Override
	public Set<Customer> getAllCustomers() {

		return dao.getAllCustomers();
	}

}
