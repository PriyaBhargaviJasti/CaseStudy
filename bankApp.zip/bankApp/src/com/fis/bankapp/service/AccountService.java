package com.fis.bankapp.service;

//import java.util.Set;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.exceptions.NotEnoughBalance;
import com.fis.bankapp.exceptions.AccountNotFound;

public interface AccountService {
	public abstract String addAccount(Account account);

	public abstract String deleteAccount(long accNo) throws AccountNotFound;


	public abstract Account getAccount(long getAcc) throws AccountNotFound;
	
	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance;

	public abstract void depositIntoBalance(long getAcc, double depositAmount);
	


}
